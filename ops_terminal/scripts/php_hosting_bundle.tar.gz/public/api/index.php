<?php
require __DIR__ . '/db.php';

$db = db_connect();
$action = isset($_GET['action']) ? $_GET['action'] : '';

function media_storage_dir() {
    return realpath(__DIR__ . '/../uploads') ?: (__DIR__ . '/../uploads');
}

function media_file_path($file_url) {
    $name = basename(parse_url($file_url, PHP_URL_PATH));
    return $name !== '' ? media_storage_dir() . DIRECTORY_SEPARATOR . $name : '';
}

function media_rows($db) {
    $rows = array();
    $res = $db->query('SELECT id,file_url,file_name,mime_type,file_size,IFNULL(folder_id,0) as folder_id,created_at FROM media_library ORDER BY id DESC LIMIT 500');
    while ($row = $res->fetch_assoc()) {
        $path = media_file_path($row['file_url']);
        if ($path === '' || !is_file($path)) continue;
        $row['file_url'] = '/uploads/' . basename($path);
        $rows[] = $row;
    }
    return $rows;
}

$db->query("CREATE TABLE IF NOT EXISTS media_library (
    id INT AUTO_INCREMENT PRIMARY KEY,
    file_url TEXT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    mime_type VARCHAR(120) DEFAULT '',
    file_size INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");
$db->query("CREATE TABLE IF NOT EXISTS media_folders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(190) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");
$col_check = $db->query("SHOW COLUMNS FROM media_library LIKE 'folder_id'");
if ($col_check && $col_check->num_rows === 0) {
    $db->query("ALTER TABLE media_library ADD COLUMN folder_id INT NULL");
}
$db->query("INSERT IGNORE INTO media_folders (id,name) VALUES (1,'Нераспределенные фото')");
$db->query("CREATE TABLE IF NOT EXISTS option_groups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(190) NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");
$db->query("CREATE TABLE IF NOT EXISTS models (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(160) NOT NULL,
    base_price DECIMAL(12,2) NOT NULL DEFAULT 300000,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");
$col_check = $db->query("SHOW COLUMNS FROM models LIKE 'base_price'");
if ($col_check && $col_check->num_rows === 0) {
    $db->query("ALTER TABLE models ADD COLUMN base_price DECIMAL(12,2) NOT NULL DEFAULT 300000 AFTER name");
}
$db->query("CREATE TABLE IF NOT EXISTS options_catalog (
    id INT AUTO_INCREMENT PRIMARY KEY,
    group_id INT NULL,
    name VARCHAR(160) NOT NULL,
    image_url TEXT,
    price DECIMAL(12,2) NOT NULL DEFAULT 0,
    description TEXT,
    features_json TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");
$col_check = $db->query("SHOW COLUMNS FROM options_catalog LIKE 'group_id'");
if ($col_check && $col_check->num_rows === 0) {
    $db->query("ALTER TABLE options_catalog ADD COLUMN group_id INT NULL");
}
$db->query("INSERT IGNORE INTO option_groups (id,name,sort_order) VALUES (1,'Кровля',1)");
$db->query("INSERT IGNORE INTO option_groups (id,name,sort_order) VALUES (2,'Цвет бани',2)");
$db->query("INSERT INTO option_groups (id,name,sort_order) VALUES (3,'Двери',3) ON DUPLICATE KEY UPDATE name='Двери', sort_order=3");
$db->query("INSERT IGNORE INTO option_groups (id,name,sort_order) VALUES (4,'Окна',4)");

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'bootstrap') {
    $models = array();
    $options = array();
    $groups = array();
    $media = array();
    $folders = array();

    $res = $db->query('SELECT id,name,base_price,created_at FROM models ORDER BY id DESC');
    while ($row = $res->fetch_assoc()) $models[] = $row;

    $res2 = $db->query('SELECT o.id,o.group_id,IFNULL(g.name,\'Без группы\') as group_name,o.name,o.image_url,o.price,o.description,o.features_json,o.created_at FROM options_catalog o LEFT JOIN option_groups g ON g.id=o.group_id ORDER BY COALESCE(g.sort_order,9999), o.id DESC');
    while ($row = $res2->fetch_assoc()) {
        $row['features'] = $row['features_json'] ? json_decode($row['features_json'], true) : array();
        unset($row['features_json']);
        $options[] = $row;
    }
    $res3 = $db->query('SELECT id,name,sort_order,created_at FROM option_groups ORDER BY sort_order ASC, id ASC');
    while ($row = $res3->fetch_assoc()) $groups[] = $row;

    $media = media_rows($db);
    $res4 = $db->query('SELECT id,name,created_at FROM media_folders ORDER BY id ASC');
    while ($row = $res4->fetch_assoc()) $folders[] = $row;

    json_out(array('ok' => true, 'models' => $models, 'options' => $options, 'groups' => $groups, 'media' => $media, 'folders' => $folders));
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'media_list') {
    $media = media_rows($db);
    $folders = array();
    $res2 = $db->query('SELECT id,name,created_at FROM media_folders ORDER BY id ASC');
    while ($row = $res2->fetch_assoc()) $folders[] = $row;
    json_out(array('ok' => true, 'media' => $media, 'folders' => $folders));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'create_media_folder') {
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    if ($name === '') json_out(array('ok' => false, 'error' => 'name required'));
    $stmt = $db->prepare('INSERT INTO media_folders (name) VALUES (?)');
    $stmt->bind_param('s', $name);
    $stmt->execute();
    json_out(array('ok' => true, 'id' => $db->insert_id));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'update_media_folder') {
    $id = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    if ($id <= 0 || $name === '') json_out(array('ok' => false, 'error' => 'id/name required'));
    $stmt = $db->prepare('UPDATE media_folders SET name=? WHERE id=?');
    $stmt->bind_param('si', $name, $id);
    $stmt->execute();
    json_out(array('ok' => true));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'copy_media_folder') {
    $id = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    if ($id <= 0) json_out(array('ok' => false, 'error' => 'id required'));
    $stmt = $db->prepare('SELECT name FROM media_folders WHERE id=?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if (!$row) json_out(array('ok' => false, 'error' => 'not found'));
    $new_name = $row['name'] . ' копия';
    $stmt2 = $db->prepare('INSERT INTO media_folders (name) VALUES (?)');
    $stmt2->bind_param('s', $new_name);
    $stmt2->execute();
    json_out(array('ok' => true, 'id' => $db->insert_id));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'delete_media_folder') {
    $id = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    if ($id <= 0) json_out(array('ok' => false, 'error' => 'id required'));
    $stmt = $db->prepare('SELECT COUNT(*) c FROM media_library WHERE folder_id=?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if ($row && intval($row['c']) > 0) {
        json_out(array('ok' => false, 'error' => 'Папка не пуста'));
    }
    $stmt2 = $db->prepare('DELETE FROM media_folders WHERE id=?');
    $stmt2->bind_param('i', $id);
    $stmt2->execute();
    json_out(array('ok' => true));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'move_media') {
    $id = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    $folder_raw = isset($_POST['folder_id']) ? trim($_POST['folder_id']) : '';
    if ($id <= 0) json_out(array('ok' => false, 'error' => 'id required'));
    if ($folder_raw === '' || $folder_raw === '0') {
        $stmt = $db->prepare('UPDATE media_library SET folder_id=NULL WHERE id=?');
        $stmt->bind_param('i', $id);
        $stmt->execute();
    } else {
        $folder_id = intval($folder_raw);
        $stmt = $db->prepare('UPDATE media_library SET folder_id=? WHERE id=?');
        $stmt->bind_param('ii', $folder_id, $id);
        $stmt->execute();
    }
    json_out(array('ok' => true));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'delete_media') {
    $id = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    if ($id <= 0) json_out(array('ok' => false, 'error' => 'id required'));

    $stmt = $db->prepare('SELECT file_url FROM media_library WHERE id=?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if (!$row) json_out(array('ok' => false, 'error' => 'not found'));

    $file_url = $row['file_url'];
    $file_path = media_file_path($file_url);

    $stmt2 = $db->prepare('DELETE FROM media_library WHERE id=?');
    $stmt2->bind_param('i', $id);
    $stmt2->execute();

    $same_url = 0;
    $stmt3 = $db->prepare('SELECT COUNT(*) c FROM media_library WHERE file_url=?');
    $stmt3->bind_param('s', $file_url);
    $stmt3->execute();
    $count_row = $stmt3->get_result()->fetch_assoc();
    if ($count_row) $same_url = intval($count_row['c']);

    if ($same_url === 0 && $file_path !== '' && is_file($file_path)) {
        @unlink($file_path);
    }

    json_out(array('ok' => true));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'update_media') {
    $id = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    if ($id <= 0 || $name === '') json_out(array('ok' => false, 'error' => 'id/name required'));
    $stmt = $db->prepare('UPDATE media_library SET file_name=? WHERE id=?');
    $stmt->bind_param('si', $name, $id);
    $stmt->execute();
    json_out(array('ok' => true));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'copy_media') {
    $id = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    if ($id <= 0) json_out(array('ok' => false, 'error' => 'id required'));
    $stmt = $db->prepare('SELECT file_url,file_name,mime_type,file_size,folder_id FROM media_library WHERE id=?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if (!$row) json_out(array('ok' => false, 'error' => 'not found'));
    $source_path = media_file_path($row['file_url']);
    if ($source_path === '' || !is_file($source_path)) json_out(array('ok' => false, 'error' => 'file missing'));
    $ext = pathinfo($source_path, PATHINFO_EXTENSION);
    $stored_name = 'img_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . ($ext !== '' ? '.' . strtolower($ext) : '');
    $target_path = media_storage_dir() . DIRECTORY_SEPARATOR . $stored_name;
    if (!copy($source_path, $target_path) || !is_file($target_path)) {
        json_out(array('ok' => false, 'error' => 'copy failed'));
    }
    $new_name = preg_replace('/(\.[a-z0-9]+)$/i', ' копия$1', $row['file_name']);
    if ($new_name === $row['file_name']) $new_name = $row['file_name'] . ' копия';
    $new_url = '/uploads/' . $stored_name;
    $new_size = intval(filesize($target_path));
    $stmt2 = $db->prepare('INSERT INTO media_library (file_url,file_name,mime_type,file_size,folder_id) VALUES (?,?,?,?,?)');
    $folder = isset($row['folder_id']) ? intval($row['folder_id']) : null;
    $stmt2->bind_param('sssii', $new_url, $new_name, $row['mime_type'], $new_size, $folder);
    if (!$stmt2->execute()) {
        @unlink($target_path);
        json_out(array('ok' => false, 'error' => 'database write failed'));
    }
    json_out(array('ok' => true, 'id' => $db->insert_id));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'create_model') {
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $base_price = isset($_POST['base_price']) ? floatval($_POST['base_price']) : 300000;
    if ($name === '') json_out(array('ok' => false, 'error' => 'Model name required'));
    $stmt = $db->prepare('INSERT INTO models (name, base_price) VALUES (?, ?)');
    $stmt->bind_param('sd', $name, $base_price);
    $stmt->execute();
    json_out(array('ok' => true, 'id' => $db->insert_id));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'update_model') {
    $id = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $base_price = isset($_POST['base_price']) ? floatval($_POST['base_price']) : 300000;
    if ($id <= 0 || $name === '') json_out(array('ok' => false, 'error' => 'id/name required'));
    $stmt = $db->prepare('UPDATE models SET name=?, base_price=? WHERE id=?');
    $stmt->bind_param('sdi', $name, $base_price, $id);
    $stmt->execute();
    json_out(array('ok' => true));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'delete_model') {
    $id = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    if ($id <= 0) json_out(array('ok' => false, 'error' => 'id required'));
    $stmt = $db->prepare('DELETE FROM models WHERE id=?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    json_out(array('ok' => true));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'copy_model') {
    $source_id = intval(isset($_POST['source_id']) ? $_POST['source_id'] : 0);
    if ($source_id <= 0) json_out(array('ok' => false, 'error' => 'source_id required'));

    $stmt = $db->prepare('SELECT name, base_price FROM models WHERE id=?');
    $stmt->bind_param('i', $source_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $model = $res->fetch_assoc();
    if (!$model) json_out(array('ok' => false, 'error' => 'Model not found'));

    $new_name = $model['name'] . ' копия';
    $base_price = isset($model['base_price']) ? floatval($model['base_price']) : 300000;
    $stmt2 = $db->prepare('INSERT INTO models (name, base_price) VALUES (?, ?)');
    $stmt2->bind_param('sd', $new_name, $base_price);
    $stmt2->execute();
    $new_id = $db->insert_id;

    $stmt3 = $db->prepare('SELECT page_json FROM model_pages WHERE model_id=?');
    $stmt3->bind_param('i', $source_id);
    $stmt3->execute();
    $res3 = $stmt3->get_result();
    $page = $res3->fetch_assoc();
    if ($page && isset($page['page_json'])) {
        $stmt4 = $db->prepare('INSERT INTO model_pages (model_id,page_json) VALUES (?,?)');
        $stmt4->bind_param('is', $new_id, $page['page_json']);
        $stmt4->execute();
    }
    json_out(array('ok' => true, 'id' => $new_id));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'create_option') {
    $group_id = isset($_POST['group_id']) ? intval($_POST['group_id']) : 0;
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $image_url = isset($_POST['image_url']) ? trim($_POST['image_url']) : '';
    $price = isset($_POST['price']) ? floatval($_POST['price']) : 0;
    $description = isset($_POST['description']) ? trim($_POST['description']) : '';
    $features = isset($_POST['features']) ? $_POST['features'] : '[]';
    if ($name === '') json_out(array('ok' => false, 'error' => 'Option name required'));
    if ($group_id <= 0) $group_id = null;
    $stmt = $db->prepare('INSERT INTO options_catalog (group_id,name,image_url,price,description,features_json) VALUES (?,?,?,?,?,?)');
    $stmt->bind_param('issdss', $group_id, $name, $image_url, $price, $description, $features);
    $stmt->execute();
    json_out(array('ok' => true, 'id' => $db->insert_id));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'update_option') {
    $id = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    $group_id = isset($_POST['group_id']) ? intval($_POST['group_id']) : 0;
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $image_url = isset($_POST['image_url']) ? trim($_POST['image_url']) : '';
    $price = isset($_POST['price']) ? floatval($_POST['price']) : 0;
    $description = isset($_POST['description']) ? trim($_POST['description']) : '';
    $features = isset($_POST['features']) ? $_POST['features'] : '[]';
    if ($id <= 0 || $name === '') json_out(array('ok' => false, 'error' => 'id/name required'));
    if ($group_id <= 0) $group_id = null;
    $stmt = $db->prepare('UPDATE options_catalog SET group_id=?, name=?, image_url=?, price=?, description=?, features_json=? WHERE id=?');
    $stmt->bind_param('issdssi', $group_id, $name, $image_url, $price, $description, $features, $id);
    $stmt->execute();
    json_out(array('ok' => true));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'delete_option') {
    $id = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    if ($id <= 0) json_out(array('ok' => false, 'error' => 'id required'));
    $stmt = $db->prepare('DELETE FROM options_catalog WHERE id=?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    json_out(array('ok' => true));
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'get_page') {
    $model_id = intval(isset($_GET['model_id']) ? $_GET['model_id'] : 0);
    if ($model_id <= 0) json_out(array('ok' => false, 'error' => 'model_id required'));
    $stmt = $db->prepare('SELECT page_json FROM model_pages WHERE model_id=?');
    $stmt->bind_param('i', $model_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    json_out(array('ok' => true, 'page_json' => $row ? $row['page_json'] : ''));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'save_page') {
    $model_id = intval(isset($_POST['model_id']) ? $_POST['model_id'] : 0);
    $page_json = isset($_POST['page_json']) ? $_POST['page_json'] : '';
    if ($model_id <= 0) json_out(array('ok' => false, 'error' => 'model_id required'));

    $stmt = $db->prepare('SELECT model_id FROM model_pages WHERE model_id=?');
    $stmt->bind_param('i', $model_id);
    $stmt->execute();
    $exists = $stmt->get_result()->fetch_assoc();

    if ($exists) {
        $stmt2 = $db->prepare('UPDATE model_pages SET page_json=? WHERE model_id=?');
        $stmt2->bind_param('si', $page_json, $model_id);
        $stmt2->execute();
    } else {
        $stmt3 = $db->prepare('INSERT INTO model_pages (model_id,page_json) VALUES (?,?)');
        $stmt3->bind_param('is', $model_id, $page_json);
        $stmt3->execute();
    }
    json_out(array('ok' => true));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'upload_image') {
    if (!isset($_FILES['file']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
        json_out(array('ok' => false, 'error' => 'Файл не получен'));
    }

    $file = $_FILES['file'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $map = array(
            UPLOAD_ERR_INI_SIZE => 'Файл слишком большой для сервера',
            UPLOAD_ERR_FORM_SIZE => 'Файл слишком большой',
            UPLOAD_ERR_PARTIAL => 'Файл загружен частично',
            UPLOAD_ERR_NO_FILE => 'Файл не выбран',
            UPLOAD_ERR_NO_TMP_DIR => 'На сервере нет временной папки',
            UPLOAD_ERR_CANT_WRITE => 'Сервер не может записать файл',
            UPLOAD_ERR_EXTENSION => 'Загрузка остановлена расширением PHP'
        );
        $msg = isset($map[$file['error']]) ? $map[$file['error']] : 'Ошибка загрузки';
        json_out(array('ok' => false, 'error' => $msg));
    }

    $allowed = array('image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif');
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    if (!isset($allowed[$mime])) {
        json_out(array('ok' => false, 'error' => 'Разрешены только изображения'));
    }

    $uploads_dir = __DIR__ . '/../uploads';
    if (!is_dir($uploads_dir)) {
        mkdir($uploads_dir, 0755, true);
    }

    $ext = $allowed[$mime];
    $name = 'img_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $target = $uploads_dir . '/' . $name;
    if (!move_uploaded_file($file['tmp_name'], $target) || !is_file($target) || filesize($target) <= 0) {
        json_out(array('ok' => false, 'error' => 'Не удалось сохранить файл'));
    }

    $file_url = '/uploads/' . $name;
    $folder_raw = isset($_POST['folder_id']) ? trim($_POST['folder_id']) : '';
    $size = intval(filesize($target));
    if ($folder_raw === '' || $folder_raw === '0') {
        $stmtm = $db->prepare('INSERT INTO media_library (file_url,file_name,mime_type,file_size,folder_id) VALUES (?,?,?, ?, NULL)');
        $stmtm->bind_param('sssi', $file_url, $name, $mime, $size);
        if (!$stmtm->execute()) {
            @unlink($target);
            json_out(array('ok' => false, 'error' => 'database write failed'));
        }
    } else {
        $folder_id = intval($folder_raw);
        $stmtm = $db->prepare('INSERT INTO media_library (file_url,file_name,mime_type,file_size,folder_id) VALUES (?,?,?,?,?)');
        $stmtm->bind_param('sssii', $file_url, $name, $mime, $size, $folder_id);
        if (!$stmtm->execute()) {
            @unlink($target);
            json_out(array('ok' => false, 'error' => 'database write failed'));
        }
    }

    json_out(array('ok' => true, 'url' => $file_url));
}

http_response_code(404);
json_out(array('ok' => false, 'error' => 'Unknown route'));


